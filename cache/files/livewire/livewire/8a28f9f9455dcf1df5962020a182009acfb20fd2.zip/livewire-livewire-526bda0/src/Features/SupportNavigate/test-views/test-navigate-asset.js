
if (! window._lw_dusk_asset_count) {
    window._lw_dusk_asset_count = 1
} else {
    window._lw_dusk_asset_count++
}


