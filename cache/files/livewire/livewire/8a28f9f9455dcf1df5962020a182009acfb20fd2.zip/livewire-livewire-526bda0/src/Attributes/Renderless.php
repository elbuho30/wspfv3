<?php

namespace Livewire\Attributes;

use Livewire\Mechanisms\HandleComponents\BaseRenderless;

#[\Attribute]
class Renderless extends BaseRenderless
{
    //
}
