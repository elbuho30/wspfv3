<?php

return [

    'modal' => [

        'heading' => 'Obavijesti',

        'actions' => [

            'clear' => [
                'label' => 'Izbrišite sve',
            ],

            'mark_all_as_read' => [
                'label' => 'Označi sve kao pročitano ',
            ],

        ],

        'empty' => [
            'heading' => 'Nema obavijesti',
            'description' => 'Molimo provjerite kasnije opet',
        ],

    ],

];
