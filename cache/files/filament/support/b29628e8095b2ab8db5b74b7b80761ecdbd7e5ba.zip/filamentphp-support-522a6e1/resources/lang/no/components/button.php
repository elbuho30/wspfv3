<?php

return [

    'messages' => [
        'uploading_file' => 'Laster opp fil...',
    ],

];
