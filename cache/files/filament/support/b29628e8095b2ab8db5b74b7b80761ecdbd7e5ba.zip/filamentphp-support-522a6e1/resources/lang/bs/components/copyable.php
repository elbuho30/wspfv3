<?php

return [

    'messages' => [
        'copied' => 'Kopirano',
    ],

];
