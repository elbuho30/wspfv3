<?php

return [

    'messages' => [
        'uploading_file' => 'Загрузка файла...',
    ],

];
