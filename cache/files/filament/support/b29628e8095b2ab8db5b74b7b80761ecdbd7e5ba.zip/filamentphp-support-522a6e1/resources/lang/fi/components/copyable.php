<?php

return [

    'messages' => [
        'copied' => 'Kopioitu',
    ],

];
