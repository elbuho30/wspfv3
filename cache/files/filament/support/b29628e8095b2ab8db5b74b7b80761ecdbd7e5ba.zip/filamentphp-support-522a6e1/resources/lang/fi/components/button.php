<?php

return [

    'messages' => [
        'uploading_file' => 'Siirretään tiedostoa...',
    ],

];
