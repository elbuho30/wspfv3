<?php

return [

    'actions' => [

        'close' => [
            'label' => 'Lukk',
        ],

    ],

];
