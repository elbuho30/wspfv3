<?php

return [

    'actions' => [

        'close' => [
            'label' => 'Aizvērt',
        ],

    ],

];
