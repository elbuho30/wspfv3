<?php

return [

    'single' => [

        'label' => 'İliştir',

        'modal' => [

            'heading' => ':label iliştir',

            'fields' => [

                'record_id' => [
                    'label' => 'Kayıt',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => 'İliştir',
                ],

                'attach_another' => [
                    'label' => 'İliştir ve başka bir taneye başla',
                ],

            ],

        ],

        'notifications' => [

            'attached' => [
                'title' => 'İliştirildi',
            ],

        ],

    ],

];
