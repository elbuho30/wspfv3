<?php

return [

    'single' => [

        'label' => 'Bản sao',

        'modal' => [

            'heading' => 'Bản sao :label',

            'actions' => [

                'replicate' => [
                    'label' => 'Bản sao',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'Đã tạo bản sao',
            ],

        ],

    ],

];
