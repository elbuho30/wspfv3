<?php

return [

    'single' => [

        'label' => 'Slett',

        'modal' => [

            'heading' => 'Slett :label',

            'actions' => [

                'delete' => [
                    'label' => 'Slett',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Slettet',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Slett valgte',

        'modal' => [

            'heading' => 'Slett valgte :label',

            'actions' => [

                'delete' => [
                    'label' => 'Slett',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Slettet',
            ],

        ],

    ],

];
