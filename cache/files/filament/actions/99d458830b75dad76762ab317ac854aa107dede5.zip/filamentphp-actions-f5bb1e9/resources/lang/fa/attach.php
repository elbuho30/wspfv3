<?php

return [

    'single' => [

        'label' => 'افزودن',

        'modal' => [

            'heading' => 'افزودن :label',

            'fields' => [

                'record_id' => [
                    'label' => 'رکورد',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => 'افزودن',
                ],

                'attach_another' => [
                    'label' => 'افزودن و افزودن یکی دیگر',
                ],

            ],

        ],

        'notifications' => [

            'attached' => [
                'title' => 'افزوده شد',
            ],

        ],

    ],

];
