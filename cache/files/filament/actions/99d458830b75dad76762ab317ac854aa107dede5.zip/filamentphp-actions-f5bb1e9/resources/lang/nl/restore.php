<?php

return [

    'single' => [

        'label' => 'Herstellen',

        'modal' => [

            'heading' => ':Label herstellen',

            'actions' => [

                'restore' => [
                    'label' => 'Herstellen',
                ],

            ],

        ],

        'notifications' => [

            'restored' => [
                'title' => 'Hersteld',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Geselecteerde herstellen',

        'modal' => [

            'heading' => 'Geselecteerde :label herstellen',

            'actions' => [

                'restore' => [
                    'label' => 'Herstellen',
                ],

            ],

        ],

        'notifications' => [

            'restored' => [
                'title' => 'Hersteld',
            ],

        ],

    ],

];
