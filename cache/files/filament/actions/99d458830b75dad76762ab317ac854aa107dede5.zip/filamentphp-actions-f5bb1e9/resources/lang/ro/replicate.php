<?php

return [

    'single' => [

        'label' => 'Replicare',

        'modal' => [

            'heading' => 'Replicare :label',

            'actions' => [

                'replicate' => [
                    'label' => 'Replicare',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'Replicat cu succes',
            ],

        ],

    ],

];
