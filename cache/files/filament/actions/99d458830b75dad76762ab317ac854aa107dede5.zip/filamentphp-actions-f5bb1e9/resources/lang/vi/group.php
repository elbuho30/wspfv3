<?php

return [

    'trigger' => [
        'label' => 'Thao tác',
    ],

];
