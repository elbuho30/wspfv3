<?php

return [

    'trigger' => [
        'label' => 'Czynności',
    ],

];
