<?php

return [

    'single' => [

        'label' => 'Харах',

        'modal' => [

            'heading' => 'Харах :label',

            'actions' => [

                'close' => [
                    'label' => 'Хаах',
                ],

            ],

        ],

    ],

];
