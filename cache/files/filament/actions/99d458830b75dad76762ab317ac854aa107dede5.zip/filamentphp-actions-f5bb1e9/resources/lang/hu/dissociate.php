<?php

return [

    'single' => [

        'label' => 'Szétválasztás',

        'modal' => [

            'heading' => ':label szétválasztása',

            'actions' => [

                'dissociate' => [
                    'label' => 'Szétválasztás',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Szétválasztva',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Kiválasztottak  szétválasztása',

        'modal' => [

            'heading' => 'Kiválasztott :label szétválasztása',

            'actions' => [

                'dissociate' => [
                    'label' => 'Kiválasztottak szétválasztása',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Szétválasztva',
            ],

        ],

    ],

];
