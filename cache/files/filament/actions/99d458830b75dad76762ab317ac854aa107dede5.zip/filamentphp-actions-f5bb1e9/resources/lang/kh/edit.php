<?php

return [

    'single' => [

        'label' => 'កែប្រែ',

        'modal' => [

            'heading' => 'កែប្រែ :label',

            'actions' => [

                'save' => [
                    'label' => 'រក្សាទុក',
                ],

            ],

        ],

        'notifications' => [

            'saved' => [
                'title' => 'បានរក្សាទុកដោយជោគជ័យ',
            ],

        ],

    ],

];
