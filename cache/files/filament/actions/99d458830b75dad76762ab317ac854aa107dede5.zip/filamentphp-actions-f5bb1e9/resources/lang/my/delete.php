<?php

return [

    'single' => [

        'label' => 'ဖျက်ပါ',

        'modal' => [

            'heading' => ':label ကိုဖျက်ပါ',

            'actions' => [

                'delete' => [
                    'label' => 'ဖျက်ပါ',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'ဖျက်ပြီးပါပြီ',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Delete selected',

        'modal' => [

            'heading' => 'Delete selected :label',

            'actions' => [

                'delete' => [
                    'label' => 'Delete selected',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Deleted',
            ],

        ],

    ],

];
