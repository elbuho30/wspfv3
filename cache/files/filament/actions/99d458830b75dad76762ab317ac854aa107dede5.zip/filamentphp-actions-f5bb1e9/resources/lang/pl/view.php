<?php

return [

    'single' => [

        'label' => 'Podgląd',

        'modal' => [

            'heading' => 'Podgląd :label',

            'actions' => [

                'close' => [
                    'label' => 'Zamknij',
                ],

            ],

        ],

    ],

];
