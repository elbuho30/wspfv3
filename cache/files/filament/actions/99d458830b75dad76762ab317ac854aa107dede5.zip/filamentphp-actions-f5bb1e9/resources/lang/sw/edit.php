<?php

return [

    'single' => [

        'label' => 'Hariri',

        'modal' => [

            'heading' => 'Hariri :label',

            'actions' => [

                'save' => [
                    'label' => 'Hifadhi mabadiliko',
                ],

            ],

        ],

        'notifications' => [

            'saved' => [
                'title' => 'Imehifadhiwa',
            ],

        ],

    ],

];
