<?php

return [

    'single' => [

        'label' => 'Копіювати',

        'modal' => [

            'heading' => 'Копіювати :label',

            'actions' => [

                'replicate' => [
                    'label' => 'Копіювати',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'Запис скопійовано',
            ],

        ],

    ],

];
