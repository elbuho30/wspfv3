<?php

return [

    'confirmation' => 'Biztos, hogy végre akarja hajtani?',

    'actions' => [

        'cancel' => [
            'label' => 'Mégse',
        ],

        'confirm' => [
            'label' => 'Megerősítés',
        ],

        'submit' => [
            'label' => 'Végrahajtás',
        ],

    ],

];
