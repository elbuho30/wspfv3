<?php

return [

    'single' => [

        'label' => 'Görüntüle',

        'modal' => [

            'heading' => ':label görüntüle',

            'actions' => [

                'close' => [
                    'label' => 'Kapat',
                ],

            ],

        ],

    ],

];
