<?php

return [

    'single' => [

        'label' => '檢視',

        'modal' => [

            'heading' => '檢視 :label',

            'actions' => [

                'close' => [
                    'label' => '關閉',
                ],

            ],

        ],

    ],

];
