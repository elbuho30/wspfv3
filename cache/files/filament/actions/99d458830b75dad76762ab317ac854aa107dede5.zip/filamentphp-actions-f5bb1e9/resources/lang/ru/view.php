<?php

return [

    'single' => [

        'label' => 'Просмотр',

        'modal' => [

            'heading' => 'Просмотр :label',

            'actions' => [

                'close' => [
                    'label' => 'Закрыть',
                ],

            ],

        ],

    ],

];
