<?php

return [

    'confirmation' => '確定要進行嗎？',

    'actions' => [

        'cancel' => [
            'label' => '取消',
        ],

        'confirm' => [
            'label' => '確定',
        ],

        'submit' => [
            'label' => '送出',
        ],

    ],

];
