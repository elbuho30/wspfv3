<?php

return [

    'single' => [

        'label' => 'Editar',

        'modal' => [

            'heading' => 'Editar :label',

            'actions' => [

                'save' => [
                    'label' => 'Guardar cambios',
                ],

            ],

        ],

        'notifications' => [

            'saved' => [
                'title' => 'Guardado',
            ],

        ],

    ],

];
