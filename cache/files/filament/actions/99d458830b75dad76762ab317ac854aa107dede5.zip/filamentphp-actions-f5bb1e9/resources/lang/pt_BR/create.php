<?php

return [

    'single' => [

        'label' => 'Novo :label',

        'modal' => [

            'heading' => 'Criar :label',

            'actions' => [

                'create' => [
                    'label' => 'Criar',
                ],

                'create_another' => [
                    'label' => 'Salvar e criar outro',
                ],

            ],

        ],

        'notifications' => [

            'created' => [
                'title' => 'Criado',
            ],

        ],

    ],

];
