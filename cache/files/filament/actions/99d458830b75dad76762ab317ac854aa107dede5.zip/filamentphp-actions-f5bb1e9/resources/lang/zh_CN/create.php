<?php

return [

    'single' => [

        'label' => '创建:label',

        'modal' => [

            'heading' => '创建:label',

            'actions' => [

                'create' => [
                    'label' => '保存',
                ],

                'create_another' => [
                    'label' => '保存并创建另一个',
                ],

            ],

        ],

        'notifications' => [

            'created' => [
                'title' => '已创建',
            ],

        ],

    ],

];
