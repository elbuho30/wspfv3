<?php

return [

    'single' => [

        'label' => '解除附加',

        'modal' => [

            'heading' => '解除附加 :label',

            'actions' => [

                'detach' => [
                    'label' => '解除附加',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => '解除附加',
            ],

        ],

    ],

    'multiple' => [

        'label' => '解除附加所選的項目',

        'modal' => [

            'heading' => '解除附加所選的 :label',

            'actions' => [

                'detach' => [
                    'label' => '解除附加所選的項目',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => '已解除附加',
            ],

        ],

    ],

];
