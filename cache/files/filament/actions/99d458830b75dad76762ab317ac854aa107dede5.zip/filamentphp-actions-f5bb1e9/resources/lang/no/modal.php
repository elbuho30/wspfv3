<?php

return [

    'confirmation' => 'Are you sure you would like to do this?',

    'actions' => [

        'cancel' => [
            'label' => 'Avbryt',
        ],

        'confirm' => [
            'label' => 'Bekreft',
        ],

        'submit' => [
            'label' => 'Send',
        ],

    ],

];
