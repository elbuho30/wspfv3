<?php

return [

    'single' => [

        'label' => 'Dissociera',

        'modal' => [

            'heading' => 'Dissociera :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Dissociera',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Dissocierad',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Dissociera valda',

        'modal' => [

            'heading' => 'Dissociera valda :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Dissociera valda',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Dissocierade',
            ],

        ],

    ],

];
