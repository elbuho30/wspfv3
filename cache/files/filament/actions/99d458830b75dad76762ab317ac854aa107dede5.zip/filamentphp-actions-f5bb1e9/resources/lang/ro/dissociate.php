<?php

return [

    'single' => [

        'label' => 'Disociere',

        'modal' => [

            'heading' => 'Disociere :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Disociere',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Disociat cu succes',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Disociați înregistrările selectate',

        'modal' => [

            'heading' => 'Disociați :label selectate',

            'actions' => [

                'dissociate' => [
                    'label' => 'Disociați înregistrările selectate',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Disociat cu succes',
            ],

        ],

    ],

];
