<?php

return [

    'single' => [

        'label' => '强制删除',

        'modal' => [

            'heading' => '强制删除 :label',

            'actions' => [

                'delete' => [
                    'label' => '删除',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => '记录已删除',
            ],

        ],

    ],

    'multiple' => [

        'label' => '强制删除已选项目',

        'modal' => [

            'heading' => '强制删除已选 :label',

            'actions' => [

                'delete' => [
                    'label' => '删除',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => '记录已删除',
            ],

        ],

    ],

];
