<?php

return [

    'single' => [

        'label' => 'Visa',

        'modal' => [

            'heading' => 'Visa :label',

            'actions' => [

                'close' => [
                    'label' => 'Stäng',
                ],

            ],

        ],

    ],

];
