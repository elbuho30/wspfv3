<?php

return [

    'single' => [

        'label' => 'Editar',

        'modal' => [

            'heading' => 'Editar :label',

            'actions' => [

                'save' => [
                    'label' => 'Guardar',
                ],

            ],

        ],

        'notifications' => [

            'saved' => [
                'title' => 'Guardado!',
            ],

        ],

    ],

];
