<?php

return [

    'breadcrumb' => 'Список',

];
