<?php

return [

    'field' => [
        'label' => 'Глобальный поиск',
        'placeholder' => 'Поиск',
    ],

    'no_results_message' => 'Ничего не найдено.',

];
