<?php

return [

    'breadcrumb' => 'Listar',

];
