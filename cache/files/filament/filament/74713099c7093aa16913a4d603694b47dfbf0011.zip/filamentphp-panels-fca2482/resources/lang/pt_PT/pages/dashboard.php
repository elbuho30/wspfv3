<?php

return [

    'title' => 'Painel de Controlo',

];
