<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'Simpan perubahan',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Disimpan',
        ],

    ],

];
