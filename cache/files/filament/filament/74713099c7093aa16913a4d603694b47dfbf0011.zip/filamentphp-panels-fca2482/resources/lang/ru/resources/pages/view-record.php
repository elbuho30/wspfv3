<?php

return [

    'title' => 'Просмотр :label',

    'breadcrumb' => 'Просмотр',

    'content' => [

        'tab' => [
            'label' => 'Просмотр',
        ],

    ],

];
