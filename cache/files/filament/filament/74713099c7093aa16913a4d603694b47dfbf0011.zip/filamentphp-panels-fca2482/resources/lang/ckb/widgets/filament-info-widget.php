<?php

return [

    'actions' => [

        'open_documentation' => [
            'label' => 'Documentation',
        ],

        'open_github' => [
            'label' => 'GitHub',
        ],

    ],

];
