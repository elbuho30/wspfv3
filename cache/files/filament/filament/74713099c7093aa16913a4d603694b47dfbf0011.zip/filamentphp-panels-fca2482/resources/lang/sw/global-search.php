<?php

return [

    'field' => [
        'label' => 'Tafuta kote',
        'placeholder' => 'Tafuta',
    ],

    'no_results_message' => 'Hakuna matokeo ya utafutaji yaliyopatikana.',

];
