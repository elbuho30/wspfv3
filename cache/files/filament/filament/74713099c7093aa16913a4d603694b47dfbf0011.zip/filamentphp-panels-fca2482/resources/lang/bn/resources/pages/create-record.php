<?php

return [

    'title' => ':label তৈরী করুন',

    'breadcrumb' => 'তৈরী করুন',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'বাতিল',
            ],

            'create' => [
                'label' => 'তৈরী করুন',
            ],

            'create_another' => [
                'label' => 'তৈরী এবং পুনরায় তৈরী করুন',
            ],

        ],

    ],

    'notifications' => [

        'created' => [
            'title' => 'তৈরি হয়েছে',
        ],

    ],

];
