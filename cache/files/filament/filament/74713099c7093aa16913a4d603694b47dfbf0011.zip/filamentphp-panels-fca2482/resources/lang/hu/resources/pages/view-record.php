<?php

return [

    'title' => ':label megtekintése',

    'breadcrumb' => 'Megtekintés',

    'content' => [

        'tab' => [
            'label' => 'Megtekintés',
        ],

    ],

];
