<?php

return [

    'title' => 'Guarda :label',

    'breadcrumb' => 'Guarda',

    'content' => [

        'tab' => [
            'label' => 'Guarda',
        ],

    ],

];
