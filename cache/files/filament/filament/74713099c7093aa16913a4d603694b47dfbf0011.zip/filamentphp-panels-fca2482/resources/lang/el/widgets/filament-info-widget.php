<?php

return [

    'actions' => [

        'open_documentation' => [
            'label' => 'Οδηγός',
        ],

        'open_github' => [
            'label' => 'GitHub',
        ],

    ],

];
