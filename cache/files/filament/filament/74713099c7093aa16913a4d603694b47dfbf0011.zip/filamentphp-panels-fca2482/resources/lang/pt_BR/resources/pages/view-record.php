<?php

return [

    'title' => 'Mostrar :label',

    'breadcrumb' => 'Mostrar',

    'content' => [

        'tab' => [
            'label' => 'Mostrar',
        ],

    ],

];
