<?php

return [

    'actions' => [

        'logout' => [
            'label' => 'Terminar Sessão',
        ],

    ],

    'welcome' => 'Bem-vindo',

];
