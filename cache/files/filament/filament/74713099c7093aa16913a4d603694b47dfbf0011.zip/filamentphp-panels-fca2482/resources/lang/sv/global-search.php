<?php

return [

    'field' => [
        'label' => 'Global sökning',
        'placeholder' => 'Sök',
    ],

    'no_results_message' => 'Inga sökresultat.',

];
