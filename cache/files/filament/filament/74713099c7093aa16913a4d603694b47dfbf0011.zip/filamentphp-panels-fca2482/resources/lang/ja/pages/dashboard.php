<?php

return [

    'title' => 'ダッシュボード',

];
