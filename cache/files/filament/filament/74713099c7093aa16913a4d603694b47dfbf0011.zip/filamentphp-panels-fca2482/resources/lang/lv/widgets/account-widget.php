<?php

return [

    'actions' => [

        'logout' => [
            'label' => 'Iziet',
        ],

    ],

    'welcome' => 'Laipni lūdzam',

];
