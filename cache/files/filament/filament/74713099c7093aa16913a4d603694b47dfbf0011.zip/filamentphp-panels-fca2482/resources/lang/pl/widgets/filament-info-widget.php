<?php

return [

    'actions' => [

        'open_documentation' => [
            'label' => 'Dokumentacja',
        ],

        'open_github' => [
            'label' => 'GitHub',
        ],

    ],

];
