<?php

return [

    'actions' => [

        'open_documentation' => [
            'label' => 'Dokumentáció',
        ],

        'open_github' => [
            'label' => 'GitHub',
        ],

    ],

];
