<?php

return [

    'title' => ':label 보기',

    'breadcrumb' => '보기',

];
