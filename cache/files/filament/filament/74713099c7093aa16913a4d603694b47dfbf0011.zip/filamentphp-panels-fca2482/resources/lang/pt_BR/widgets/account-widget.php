<?php

return [

    'actions' => [

        'logout' => [
            'label' => 'Logout',
        ],

    ],

    'welcome' => 'Bem-vindo',

];
