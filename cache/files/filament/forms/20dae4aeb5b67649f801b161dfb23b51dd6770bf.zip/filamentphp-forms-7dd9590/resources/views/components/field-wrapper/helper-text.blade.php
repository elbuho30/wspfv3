<div
    {{ $attributes->class(['fi-fo-field-wrp-helper-text text-sm text-gray-500']) }}
>
    {{ $slot }}
</div>
