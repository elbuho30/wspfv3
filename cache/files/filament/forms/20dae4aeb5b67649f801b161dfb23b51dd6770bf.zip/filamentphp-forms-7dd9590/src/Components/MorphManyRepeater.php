<?php

namespace Filament\Forms\Components;

/**
 * @deprecated Use `Repeater` with the `relationship()` method instead.
 */
class MorphManyRepeater extends RelationshipRepeater
{
}
