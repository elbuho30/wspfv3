<?php

namespace Filament\Tables\Columns;

class ViewColumn extends Column
{
}
